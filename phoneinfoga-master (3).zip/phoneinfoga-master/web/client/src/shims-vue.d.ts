declare module "*.vue" {
  import Vue from "vue";
  export default Vue;
}
declare module "vue-json-viewer" {}
declare module "vue-phone-number-input" {}
